Hello!

Hopefully zipping and unzipping this file has not caused any issues. Please email me if it has, and I can email you a Google Drive link instead. 

I have created 3 separate folders with 3 different test cases: (the only difference between the 3 folders is the given chord progression)
1. Only errors
2. No errors
3. Mixture of both

This will help you see the program working at its full potential. 


Each folder has 3 code files: 
1. main.py - actual python code
2. chord_progression.txt - where the user inputs the chord progression
3. sheet_music.ly - where the lilypond code is generated

sheet_music.pdf is the pdf file generated with the scales after running the program. 


I have answered the 4 questions in the code itself; it's been copied to the other versions of the code as well. 

Enjoy!

- Samvit Prem Singhal